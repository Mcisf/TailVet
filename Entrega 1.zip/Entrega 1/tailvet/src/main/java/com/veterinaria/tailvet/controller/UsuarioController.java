package com.veterinaria.tailvet.controller;

import com.veterinaria.tailvet.model.Mascota;
import com.veterinaria.tailvet.model.Usuario;
import com.veterinaria.tailvet.service.UsuarioService;
import com.veterinaria.tailvet.service.MascotaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private MascotaService mascotaService;

    @GetMapping("/login")
    public String login() {
        return "login"; // Nombre del archivo HTML para el login
    }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, Model model) {
        if (usuarioService.authenticate(email, password)) {
            return "redirect:/profile"; // Redirige a la página de perfil o dashboard
        } else {
            model.addAttribute("error", "Credenciales inválidas");
            return "login";
        }
    }

    @GetMapping("/register")
    public String register() {
        return "register"; // Nombre del archivo HTML para el registro
    }

    @PostMapping("/register")
    public String register(@RequestParam String nombre, @RequestParam String email, @RequestParam String password,
                           @RequestParam String direccion, @RequestParam String telefono,
                           @RequestParam int edad, @RequestParam double peso, @RequestParam String imagenUrl,
                           @RequestParam String mascotaNombre, @RequestParam String mascotaRaza,
                           @RequestParam int mascotaEdad, @RequestParam double mascotaPeso,
                           @RequestParam String mascotaImagen, @RequestParam String mascotaEnfermedad) {

        boolean exito = usuarioService.registrarUsuario(nombre, email, password, direccion, telefono, edad, peso, imagenUrl);

        if (exito) {
            Usuario usuario = usuarioService.findByEmail(email);
            if (usuario != null) {
                Mascota mascota = new Mascota();
                mascota.setNombre(mascotaNombre);
                mascota.setRaza(mascotaRaza);
                mascota.setEdad(mascotaEdad);
                mascota.setPeso(mascotaPeso);
                mascota.setImagen(mascotaImagen);
                mascota.setUsuario(usuario);

                mascotaService.save(mascota);
            }

            return "redirect:/login"; // Redirige a la pantalla de login después del registro
        } else {
            return "redirect:/register?error"; // Redirigir a la página de registro con un parámetro de error
        }
    }

    @GetMapping("/profile")
    public String profile() {
        return "profile"; // Nombre del archivo HTML para el perfil
    }

    @GetMapping("/usuarios")
    public String listarUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioService.findAllUsuarios());
        return "admin-lista-usuarios"; // Nombre del archivo HTML para listar los usuarios
    }

    
}
