package com.veterinaria.tailvet.controller;

import com.veterinaria.tailvet.model.Mascota;
import com.veterinaria.tailvet.model.Usuario;
import com.veterinaria.tailvet.service.MascotaService;
import com.veterinaria.tailvet.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private MascotaService mascotaService;

    @GetMapping("/admin")
    public String adminPanel(Model model) {
        model.addAttribute("usuarios", usuarioService.findAllUsuarios());
        model.addAttribute("mascotas", mascotaService.findAll());
        return "admin";
    }

    @GetMapping("/mascota/{id}/detalles")
    public String verDetallesMascota(@PathVariable("id") Long id, Model model) {
        Mascota mascota = mascotaService.findById(id);
        if (mascota != null) {
            model.addAttribute("mascota", mascota);
            return "mascota-detalle"; // Asegúrate de que el nombre del archivo sea "mascota-detalle.html"
        } else {
            model.addAttribute("error", "Mascota no encontrada");
            return "redirect:/admin"; // Redirige a la página de administración si no se encuentra la mascota
        }
    }

    @PostMapping("/mascota/{id}/actualizar")
    public String updateMascota(@PathVariable("id") Long id, @ModelAttribute Mascota mascota, Model model) {
        Mascota existingMascota = mascotaService.findById(id);
        if (existingMascota != null) {
            existingMascota.setNombre(mascota.getNombre());
            existingMascota.setEdad(mascota.getEdad());
            existingMascota.setRaza(mascota.getRaza());
            existingMascota.setPeso(mascota.getPeso()); // Asegúrate de tener este campo en el modelo
            existingMascota.setImagen(mascota.getImagen());
            existingMascota.setEnfermedad(mascota.getEnfermedad()); // Asegúrate de tener este campo en el modelo
            // Actualiza otros campos según sea necesario
            mascotaService.save(existingMascota);
            return "redirect:/admin"; // Redirige a la página de administración después de actualizar
        } else {
            model.addAttribute("error", "Mascota no encontrada");
            return "mascota-detalle"; // Vuelve a la vista de detalles con un mensaje de error
        }
    }

    @GetMapping("/usuarios/editar/{id}")
        public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
            Usuario usuario = usuarioService.findById(id);
            if (usuario != null) {
                model.addAttribute("usuario", usuario);
                return "admin-editar-usuario";
            } else {
                model.addAttribute("error", "Usuario no encontrado");
                return "redirect:/admin";
            }
}



    @PostMapping("/usuarios/actualizar/{id}")
    public String actualizarUsuario(@PathVariable Long id,
                                    @RequestParam String nombre,
                                    @RequestParam String email,
                                    @RequestParam String password,
                                    @RequestParam String direccion,
                                    @RequestParam String telefono,
                                    @RequestParam String cedula,
                                    Model model) {
        Usuario usuarioActualizado = new Usuario();
        usuarioActualizado.setId(id);
        usuarioActualizado.setNombre(nombre);
        usuarioActualizado.setEmail(email);
        usuarioActualizado.setPassword(password);
        usuarioActualizado.setDireccion(direccion);
        usuarioActualizado.setTelefono(telefono);
        usuarioActualizado.setCedula(cedula);

        Usuario usuario = usuarioService.updateUsuario(id, usuarioActualizado);
        if (usuario != null) {
            return "redirect:/admin"; // Redirige a la página de administración después de la actualización
        } else {
            model.addAttribute("error", "Error al actualizar el usuario");
            return "admin-editar-usuario"; // Mantiene al usuario en el formulario de edición si hay un error
        }
    }

    @PostMapping("/usuarios/eliminar/{id}")
    public String eliminarUsuario(@PathVariable Long id) {
        usuarioService.deleteUsuario(id);
        return "redirect:/admin"; // Redirige a la página de administración después de eliminar
    }
}
