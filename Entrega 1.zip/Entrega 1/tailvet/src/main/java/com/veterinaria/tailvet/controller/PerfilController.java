package com.veterinaria.tailvet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import jakarta.servlet.http.HttpSession;

import com.veterinaria.tailvet.model.Usuario;
import com.veterinaria.tailvet.repository.MascotaRepository;
import com.veterinaria.tailvet.repository.UsuarioRepository;

@Controller
public class PerfilController {

    @Autowired
    private MascotaRepository mascotaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository; // Añadido para obtener el usuario de la base de datos

    @GetMapping("/perfil")
    public String showUserProfile(HttpSession session, Model model) {
        // Obtener el usuario de la sesión
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        
        // Si no hay un usuario en la sesión, redirigir al login
        if (usuario == null) {
            return "redirect:/login"; // Asegúrate de que la URL de login sea correcta
        }
        
        // Obtener el usuario actualizado desde la base de datos
        usuario = usuarioRepository.findById(usuario.getId()).orElse(usuario);
        
        // Añadir el usuario al modelo
        model.addAttribute("usuario", usuario);
        
        // Obtener las mascotas del usuario y añadirlas al modelo
        model.addAttribute("mascotas", mascotaRepository.findByUsuario(usuario));
        
        return "perfil";
    }
}
