package com.veterinaria.tailvet.controller;

import com.veterinaria.tailvet.model.Mascota;
import com.veterinaria.tailvet.model.Usuario;
import com.veterinaria.tailvet.model.Veterinario;
import com.veterinaria.tailvet.repository.MascotaRepository;
import com.veterinaria.tailvet.repository.UsuarioRepository;
import com.veterinaria.tailvet.repository.VeterinarioRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.*;


import jakarta.servlet.http.HttpSession;

@Controller
public class MascotaController {

    @Autowired
    private MascotaRepository mascotaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private VeterinarioRepository veterinarioRepository;

    @GetMapping("/registro-mascota")
    public String showRegisterForm() {
        return "registro-mascota";
    }

    @PostMapping("/registro-mascota")
    public String registerMascota(
            @RequestParam String nombre,
            @RequestParam String raza,
            @RequestParam int edad,
            @RequestParam double peso,
            @RequestParam String imagen,
            @RequestParam String enfermedad,
            @RequestParam String estado,  // Cambiado a String
            @RequestParam Long usuarioId,
            @RequestParam Long veterinarioId,
            HttpSession session,
            Model model) {

        // Obtener el usuario y veterinario a partir de los IDs
        Usuario usuario = usuarioRepository.findById(usuarioId).orElse(null);
        Veterinario veterinario = veterinarioRepository.findById(veterinarioId).orElse(null);

        if (usuario == null) {
            model.addAttribute("error", "Usuario no encontrado.");
            return "registro-mascota";
        }

        if (veterinario == null) {
            model.addAttribute("error", "Veterinario no encontrado.");
            return "registro-mascota";
        }

        // Crear y guardar la nueva mascota
        Mascota mascota = new Mascota();
        mascota.setNombre(nombre);
        mascota.setRaza(raza);
        mascota.setEdad(edad);
        mascota.setPeso(peso);
        mascota.setImagen(imagen);
        mascota.setEnfermedad(enfermedad);
        mascota.setEstado(estado);  // Asignar el estado
        mascota.setUsuario(usuario);
        mascota.setVeterinario(veterinario);

        mascotaRepository.save(mascota);

        // Redirigir al perfil del veterinario
        return "redirect:/veterinario/" + veterinarioId;
    }

        // Método para el veterinario
        @GetMapping("/veterinario/editar-mascota/{id}")
        public String showVeterinarioEditForm(@PathVariable Long id, Model model) {
            Mascota mascota = mascotaRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Mascota no encontrada: " + id));
            model.addAttribute("mascota", mascota);
            return "editar-mascota-veterinario";
        }
    
        @PostMapping("/veterinario/actualizar-mascota/{id}")
        public String updateMascotaVeterinario(@PathVariable Long id,
                                               @RequestParam String nombre,
                                               @RequestParam String raza,
                                               @RequestParam int edad,
                                               @RequestParam double peso,
                                               @RequestParam String imagen,
                                               @RequestParam String enfermedad,
                                               @RequestParam String estado) {
            Mascota mascota = mascotaRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Mascota no encontrada: " + id));
            mascota.setNombre(nombre);
            mascota.setRaza(raza);
            mascota.setEdad(edad);
            mascota.setPeso(peso);
            mascota.setImagen(imagen);
            mascota.setEnfermedad(enfermedad);
            mascota.setEstado(estado);
            mascotaRepository.save(mascota);
    
            return "redirect:/veterinario/" + mascota.getVeterinario().getId();
        }
}
