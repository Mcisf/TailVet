package com.veterinaria.tailvet.service;

import com.veterinaria.tailvet.model.Mascota;
import com.veterinaria.tailvet.repository.MascotaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MascotaService {

    @Autowired
    private MascotaRepository mascotaRepository;

    // Guarda una nueva mascota o actualiza una existente
    public Mascota save(Mascota mascota) {
        return mascotaRepository.save(mascota);
    }

    // Encuentra todas las mascotas
    public List<Mascota> findAll() {
        return mascotaRepository.findAll();
    }

    // Encuentra una mascota por su ID
    public Mascota findById(Long id) {
        return mascotaRepository.findById(id).orElse(null);
    }

    // Actualiza una mascota existente
    public void updateMascota(Mascota mascota) {
        if (mascota != null && mascota.getId() != null) {
            mascotaRepository.save(mascota); // Utiliza save para actualizar
        }
    }
}
