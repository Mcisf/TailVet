package com.veterinaria.tailvet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.veterinaria.tailvet.model.Usuario;
import com.veterinaria.tailvet.model.Veterinario;
import com.veterinaria.tailvet.repository.UsuarioRepository;
import com.veterinaria.tailvet.service.VeterinarioService;

import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private VeterinarioService veterinarioService;

    @GetMapping("/tipo-usuario")
    public String showLoginTypeSelection() {
        return "seleccionar-tipo-usuario";
    }

    @GetMapping("/login-cliente")
    public String showLoginClienteForm() {
        return "login-cliente";
    }

    @PostMapping("/login-cliente")
        public String loginCliente(@RequestParam String cedula, Model model, HttpSession session) {
            Usuario cliente = usuarioRepository.findByCedula(cedula);

            // Verificar si el cliente existe
            if (cliente == null) {
                model.addAttribute("error", "Cédula no encontrada.");
                return "login-cliente";
            }

            // Almacenar el cliente en la sesión
            session.setAttribute("usuario", cliente);
            
            return "redirect:/perfil";
        }

    @GetMapping("/login-veterinario")
        public String showLoginVeterinarioForm() {
            return "login-veterinario";
        }  
        
        
    @PostMapping("/login-veterinario")
    public String loginVeterinario(@RequestParam String email, @RequestParam String password, Model model, HttpSession session) {
        // Buscar el veterinario por email usando el servicio
        Veterinario veterinario = veterinarioService.obtenerVeterinarioPorEmail(email);

        // Verificar si el veterinario existe y la contraseña es correcta
        if (veterinario == null || !veterinario.getPassword().equals(password)) {
            model.addAttribute("error", "Correo o contraseña incorrectos.");
            return "login-veterinario";
        }

        // Almacenar el veterinario en la sesión
        session.setAttribute("usuario", veterinario);
        
        // Redirigir al perfil del veterinario
        return "redirect:/veterinario/" + veterinario.getId();
    }



    @GetMapping("/logout")
    public String logoutUser(HttpSession session) {
        // Invalidar la sesión para cerrar sesión
        session.invalidate();
        return "redirect:/login-cliente";
    }
}
