package com.veterinaria.tailvet.service;

import com.veterinaria.tailvet.model.Veterinario;
import com.veterinaria.tailvet.repository.VeterinarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VeterinarioService {

    @Autowired
    private VeterinarioRepository veterinarioRepository;

    public Veterinario obtenerVeterinarioPorId(Long id) {
        return veterinarioRepository.findById(id).orElse(null);
    }

    public List<Veterinario> obtenerTodosLosVeterinarios() {
        return veterinarioRepository.findAll();
    }

    public Veterinario obtenerVeterinarioPorEmail(String email) {
        return veterinarioRepository.findByEmail(email);
    }
}
