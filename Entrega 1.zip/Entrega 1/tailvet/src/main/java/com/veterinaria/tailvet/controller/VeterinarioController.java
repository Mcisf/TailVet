package com.veterinaria.tailvet.controller;

import com.veterinaria.tailvet.model.Veterinario;
import com.veterinaria.tailvet.service.VeterinarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class VeterinarioController {

    @Autowired
    private VeterinarioService veterinarioService;

    @GetMapping("/veterinario/{id}")
    public String verPerfilVeterinario(@PathVariable Long id, Model model) {
        Veterinario veterinario = veterinarioService.obtenerVeterinarioPorId(id);
        if (veterinario != null) {
            model.addAttribute("veterinario", veterinario);
            return "perfil_veterinario";
        }
        return "error";
    }
}
