-- Insertar un usuario con los nuevos campos
INSERT INTO usuario (nombre, email, password, direccion, telefono, cedula) 
VALUES ('Juan Pérez', 'juan.perez@example.com', 'password123', 'Calle Falsa 123', '555-1234', '123456789');

INSERT INTO usuario (nombre, email, password, direccion, telefono, cedula) 
VALUES ('María González', 'maria.gonzalez@example.com', 'password456', 'Avenida Siempre Viva 742', '555-5678', '987654321');

INSERT INTO usuario (nombre, email, password, direccion, telefono, cedula) 
VALUES ('Pedro Martínez', 'pedro.martinez@example.com', 'password789', 'Calle Nueva 456', '555-8765', '112233445');

INSERT INTO usuario (nombre, email, password, direccion, telefono, cedula) 
VALUES ('Laura Fernández', 'laura.fernandez@example.com', 'password321', 'Boulevard Central 123', '555-3456', '556677889');

INSERT INTO usuario (nombre, email, password, direccion, telefono, cedula) 
VALUES ('Carlos Ruiz', 'carlos.ruiz@example.com', 'password654', 'Calle de la Paz 789', '555-2345', '778899001');

INSERT INTO usuario (nombre, email, password, direccion, telefono, cedula) 
VALUES ('Sofía Morales', 'sofia.morales@example.com', 'password987', 'Plaza Mayor 987', '555-6789', '223344556');

INSERT INTO veterinario (nombre, especialidad, email, password, telefono) 
VALUES ('Dr. Eduardo Moreno', 'Oncología', 'eduardo.moreno@example.com', 'contraseña_segura7' , '12345678');

INSERT INTO veterinario (nombre, especialidad, email, password, telefono) 
VALUES ('Dra. Laura Sánchez', 'Gastroenterología', 'laura.sanchez@example.com', 'contraseña_segura8' , '12345678');

INSERT INTO veterinario (nombre, especialidad, email, password, telefono) 
VALUES ('Dr. Javier Gómez', 'Endocrinología', 'javier.gomez@example.com', 'contraseña_segura9' , '12345678');

INSERT INTO veterinario (nombre, especialidad, email, password, telefono) 
VALUES ('Dra. Marta Rodríguez', 'Medicina Preventiva', 'marta.rodriguez@example.com', 'contraseña_segura10' , '12345678');

INSERT INTO veterinario (nombre, especialidad, email, password, telefono) 
VALUES ('Dr. Alberto Ruiz', 'Rehabilitación', 'alberto.ruiz@example.com', 'contraseña_segura11' , '12345678');

INSERT INTO veterinario (nombre, especialidad, email, password, telefono) 
VALUES ('Dra. Patricia Ortega', 'Toxicología', 'patricia.ortega@example.com', 'contraseña_segura12' , '12345678');


-- Mascotas asociadas al usuario con ID 1
INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Rex', 'Pastor Alemán', 5, 30.5, 'rex.jpg', 1, 1, 'Displasia de cadera');

INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Luna', 'Bulldog', 3, 25.0, 'luna.jpg', 1, 1, 'Problemas respiratorios');

-- Mascotas asociadas al usuario con ID 2
INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Simba', 'Golden Retriever', 4, 35.0, 'simba.jpg', 2, 2, 'Displasia de cadera');

INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Mia', 'Poodle', 2, 15.0, 'mia.jpg', 2, 2, 'Otitis');

-- Mascotas asociadas al usuario con ID 3
INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Rocco', 'Boxer', 6, 28.0, 'rocco.jpg', 3, 3, 'Problemas cardíacos');

INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Luna', 'Schnauzer', 3, 18.0, 'luna_boxer.jpg', 3, 3, 'Dermatitis');

-- Mascotas asociadas al usuario con ID 4
INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Rocky', 'Beagle', 5, 20.0, 'rocky.jpg', 4, 4, 'Epilepsia');

INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Bella', 'Yorkshire Terrier', 4, 8.0, 'bella.jpg', 4, 4, 'Problemas dentales');

-- Mascotas asociadas al usuario con ID 5
INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Max', 'Cocker Spaniel', 7, 22.0, 'max.jpg', 5, 5, 'Otitis');

INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Coco', 'Shih Tzu', 2, 10.0, 'coco.jpg', 5, 5, 'Luxación de rótula');

-- Mascotas asociadas al usuario con ID 6
INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Nala', 'Pomeranian', 1, 5.0, 'nala.jpg', 6, 6, 'Colapso traqueal');

INSERT INTO mascota (nombre, raza, edad, peso, imagen, usuario_id, veterinario_id, enfermedad) 
VALUES ('Oscar', 'Dachshund', 3, 12.0, 'oscar.jpg', 6, 6, 'Problemas de espalda');


---------------------------------------------------------------------------------------------------

INSERT INTO veterinario (nombre, especialidad, email, password) 
VALUES ('Dr. Juan Pérez', 'Cirugía', 'juan.perez@example.com', 'contraseña_segura');

ALTER TABLE mascota
ADD COLUMN estado VARCHAR(10) DEFAULT 'ACTIVO';
