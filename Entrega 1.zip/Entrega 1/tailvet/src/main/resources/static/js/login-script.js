document.getElementById('showRegister').addEventListener('click', function() {
    // Aquí puedes añadir lógica para redirigir a la pantalla de inicio de sesión
    window.location.href = '/registro'; // Asegúrate de que esta ruta sea correcta
});