document.getElementById('showLogin').addEventListener('click', function() {
    document.getElementById('container').classList.add('active');
});
