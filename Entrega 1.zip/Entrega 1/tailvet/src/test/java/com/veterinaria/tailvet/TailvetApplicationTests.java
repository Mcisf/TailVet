package com.veterinaria.tailvet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TailvetApplicationTests {

	@Test
	void contextLoads() {
	}

}
